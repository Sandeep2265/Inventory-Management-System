import pymysql
import pymysql.cursors
from config import DB_HOST, DB_NAME, DB_CONFIG


def get_connection(role: str):
    """
    Opens a MySQL connection using the credentials for the given app role.
    This is what makes access control real: if a Viewer session somehow
    reaches an INSERT/UPDATE query, MySQL itself rejects it -- not just
    the Flask route.
    """
    role = (role or "viewer").lower()
    creds = DB_CONFIG.get(role, DB_CONFIG["viewer"])

    return pymysql.connect(
        host=DB_HOST,
        user=creds["user"],
        password=creds["password"],
        database=DB_NAME,
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=False,
    )
