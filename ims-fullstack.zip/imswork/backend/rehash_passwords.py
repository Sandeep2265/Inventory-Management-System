"""
Run this once after schema_final.sql to set real, working passwords.
MySQL can't hash passwords for you -- hashing always happens in the
application layer, so this script does it and writes the hash into the DB.

Usage:
    python rehash_passwords.py
Then follow the prompts to set a password for each Admin/User row.
"""

import pymysql
from werkzeug.security import generate_password_hash

from config import DB_HOST, DB_NAME, DB_CONFIG

conn = pymysql.connect(
    host=DB_HOST,
    user=DB_CONFIG["admin"]["user"],
    password=DB_CONFIG["admin"]["password"],
    database=DB_NAME,
    cursorclass=pymysql.cursors.DictCursor,
)

try:
    with conn.cursor() as cur:
        cur.execute("SELECT Admin_ID FROM Admins")
        for row in cur.fetchall():
            new_password = input(f"New password for Admin '{row['Admin_ID']}': ")
            cur.execute(
                "UPDATE Admins SET Admin_Password = %s WHERE Admin_ID = %s",
                (generate_password_hash(new_password), row["Admin_ID"]),
            )

        cur.execute("SELECT User_ID FROM Users")
        for row in cur.fetchall():
            new_password = input(f"New password for User '{row['User_ID']}': ")
            cur.execute(
                "UPDATE Users SET User_Password = %s WHERE User_ID = %s",
                (generate_password_hash(new_password), row["User_ID"]),
            )
    conn.commit()
    print("Done.")
finally:
    conn.close()
