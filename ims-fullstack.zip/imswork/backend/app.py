"""
IMS backend API.

Every route talks to the real MySQL database (see schema_final.sql) --
nothing is stored in memory or localStorage. Sales/Purchases go through
your existing stored procedures (InsertSale / InsertPurchase) so the
transaction-integrity logic lives in one place: the database.
"""

from functools import wraps

import pymysql
from flask import Flask, jsonify, request, session, send_from_directory
from werkzeug.security import check_password_hash, generate_password_hash

from config import SECRET_KEY
from db import get_connection

app = Flask(__name__, static_folder="../frontend-react/dist", static_url_path="")
app.config["SECRET_KEY"] = SECRET_KEY


# ---------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------
def require_role(*allowed_roles):
    """Blocks the route unless the logged-in session has one of allowed_roles.
    With no roles given, any logged-in user is allowed."""
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            role = session.get("role")
            if not role:
                return jsonify(success=False, message="Not logged in"), 401
            if allowed_roles and role not in allowed_roles:
                return jsonify(success=False, message=f"'{role}' cannot do this"), 403
            return fn(*args, **kwargs)
        return wrapper
    return decorator


def current_role():
    return session.get("role", "viewer")


# ---------------------------------------------------------------
# Auth routes
# ---------------------------------------------------------------
@app.route("/api/login", methods=["POST"])
def login():
    data = request.get_json(force=True)
    admin_id = data.get("id", "")
    password = data.get("password", "")

    conn = get_connection("viewer")
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT a.Admin_ID, a.Admin_Password, r.Role_Name
                FROM Admins a
                JOIN Roles r ON a.Role_ID = r.Role_ID
                WHERE a.Admin_ID = %s
                """,
                (admin_id,),
            )
            row = cur.fetchone()
    finally:
        conn.close()

    if not row or not check_password_hash(row["Admin_Password"], password):
        return jsonify(success=False, message="Invalid credentials"), 401

    expected_role = data.get("expected_role")
    if expected_role and expected_role != row["Role_Name"]:
        return jsonify(success=False, message=f"This account is registered as {row['Role_Name']}, not {expected_role}."), 403
    session.clear()
    session["admin_id"] = row["Admin_ID"]
    session["role"] = row["Role_Name"]
    session["account_type"] = "employee"
    return jsonify(success=True, id=row["Admin_ID"], role=row["Role_Name"], account_type="employee")


@app.route("/api/logout", methods=["POST"])
def logout():
    session.clear()
    return jsonify(success=True)


@app.route("/api/me")
def me():
    if session.get("account_type") == "customer":
        return jsonify(logged_in=True, id=session.get("customer_id"), name=session.get("customer_name"), role="Customer", account_type="customer")
    if "admin_id" not in session:
        return jsonify(logged_in=False)
    return jsonify(logged_in=True, id=session["admin_id"], role=session["role"], account_type="employee")


# ---------------------------------------------------------------
# Customer authentication
# ---------------------------------------------------------------
@app.route("/api/customer/signup", methods=["POST"])
def customer_signup():
    data = request.get_json(force=True)
    name, email, password = data.get("name", "").strip(), data.get("email", "").strip().lower(), data.get("password", "")
    if not name or not email or len(password) < 4:
        return jsonify(success=False, message="Name, email and a password of at least 4 characters are required"), 400
    conn = get_connection("customer")
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT User_ID FROM Users WHERE Email=%s", (email,))
            if cur.fetchone():
                return jsonify(success=False, message="An account with this email already exists"), 409
            cur.execute("SELECT User_ID FROM Users ORDER BY CAST(SUBSTRING(User_ID, 2) AS UNSIGNED) DESC LIMIT 1")
            row = cur.fetchone()
            next_id = (int(row["User_ID"][1:]) + 1) if row else 1
            user_id = f"U{next_id:03d}"
            cur.execute("INSERT INTO Users (User_ID, Name, Email, User_Password, Address) VALUES (%s,%s,%s,%s,ST_SRID(POINT(%s,%s),4326))", (user_id,name,email,generate_password_hash(password),float(data.get("lat") or 0),float(data.get("lng") or 0)))
        conn.commit()
        return jsonify(success=True, id=user_id), 201
    except pymysql.MySQLError as e:
        conn.rollback(); return jsonify(success=False, message=str(e)), 400
    finally: conn.close()

@app.route("/api/customer/login", methods=["POST"])
def customer_login():
    data=request.get_json(force=True); email=data.get("email", "").strip().lower(); password=data.get("password", "")
    conn=get_connection("customer")
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT User_ID, Name, User_Password FROM Users WHERE Email=%s", (email,)); row=cur.fetchone()
    finally: conn.close()
    if not row or not check_password_hash(row["User_Password"], password): return jsonify(success=False,message="Invalid customer credentials"),401
    session.clear(); session["customer_id"]=row["User_ID"]; session["customer_name"]=row["Name"]; session["account_type"]="customer"
    return jsonify(success=True,id=row["User_ID"],name=row["Name"],role="Customer",account_type="customer")


# ---------------------------------------------------------------
# Categories
# ---------------------------------------------------------------
@app.route("/api/categories", methods=["GET"])
def list_categories():
    conn = get_connection(current_role())
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT Category_ID AS id, Category_Name AS name FROM Categories")
            return jsonify(cur.fetchall())
    finally:
        conn.close()


@app.route("/api/categories", methods=["POST"])
@require_role("Admin", "Staff")
def create_category():
    data = request.get_json(force=True)
    conn = get_connection(current_role())
    try:
        with conn.cursor() as cur:
            cur.execute("INSERT INTO Categories (Category_Name) VALUES (%s)", (data["name"],))
        conn.commit()
        return jsonify(success=True, id=cur.lastrowid), 201
    except pymysql.MySQLError as e:
        conn.rollback()
        return jsonify(success=False, message=str(e)), 400
    finally:
        conn.close()


# ---------------------------------------------------------------
# Suppliers
# ---------------------------------------------------------------
@app.route("/api/suppliers", methods=["GET"])
def list_suppliers():
    conn = get_connection(current_role())
    try:
        with conn.cursor() as cur:
            cur.execute(
                """SELECT Supplier_ID AS id, Supplier_Name AS name, Phone AS phone,
                          ST_X(Location) AS lat, ST_Y(Location) AS lng
                   FROM Suppliers"""
            )
            return jsonify(cur.fetchall())
    finally:
        conn.close()


@app.route("/api/suppliers", methods=["POST"])
@require_role("Admin")
def create_supplier():
    data = request.get_json(force=True)
    conn = get_connection(current_role())
    try:
        with conn.cursor() as cur:
            cur.execute(
                """INSERT INTO Suppliers (Supplier_Name, Phone, Location)
                   VALUES (%s, %s, POINT(%s, %s))""",
                (data["name"], data.get("phone"), data.get("lat", 0), data.get("lng", 0)),
            )
        conn.commit()
        return jsonify(success=True, id=cur.lastrowid), 201
    except pymysql.MySQLError as e:
        conn.rollback()
        return jsonify(success=False, message=str(e)), 400
    finally:
        conn.close()


# ---------------------------------------------------------------
# Products
# ---------------------------------------------------------------
@app.route("/api/products", methods=["GET"])
def list_products():
    conn = get_connection(current_role())
    try:
        with conn.cursor() as cur:
            cur.execute(
                """SELECT Product_ID AS id, Product_Name AS name, Category_ID AS category_id,
                          Supplier_ID AS supplier_id, Total_Stock AS stock,
                          Restock AS restock, Threshold AS threshold, Price AS price
                   FROM ProductStockSummary"""
            )
            return jsonify(cur.fetchall())
    finally:
        conn.close()


@app.route("/api/products", methods=["POST"])
@require_role("Admin", "Staff")
def create_product():
    data = request.get_json(force=True)
    conn = get_connection(current_role())
    try:
        with conn.cursor() as cur:
            cur.execute(
                """INSERT INTO Products (Product_Name, Category_ID, Supplier_ID, Price, Restock, Threshold)
                   VALUES (%s, %s, %s, %s, %s, %s)""",
                (
                    data["name"], data["category_id"], data["supplier_id"], data["price"],
                    data.get("restock", 100), data.get("threshold", 40),
                ),
            )
        conn.commit()
        return jsonify(success=True, id=cur.lastrowid), 201
    except pymysql.MySQLError as e:
        conn.rollback()
        return jsonify(success=False, message=str(e)), 400
    finally:
        conn.close()


@app.route("/api/products/<int:product_id>", methods=["PUT"])
@require_role("Admin", "Staff")
def update_product(product_id):
    data = request.get_json(force=True)
    fields, values = [], []
    for key, column in [("name", "Product_Name"), ("category_id", "Category_ID"),
                         ("supplier_id", "Supplier_ID"), ("price", "Price"),
                         ("restock", "Restock"), ("threshold", "Threshold")]:
        if key in data:
            fields.append(f"{column} = %s")
            values.append(data[key])
    if not fields:
        return jsonify(success=False, message="Nothing to update"), 400

    values.append(product_id)
    conn = get_connection(current_role())
    try:
        with conn.cursor() as cur:
            cur.execute(f"UPDATE Products SET {', '.join(fields)} WHERE Product_ID = %s", values)
        conn.commit()
        return jsonify(success=True)
    except pymysql.MySQLError as e:
        conn.rollback()
        return jsonify(success=False, message=str(e)), 400
    finally:
        conn.close()


@app.route("/api/products/<int:product_id>", methods=["DELETE"])
@require_role("Admin")
def delete_product(product_id):
    conn = get_connection(current_role())
    try:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM Products WHERE Product_ID = %s", (product_id,))
        conn.commit()
        return jsonify(success=True)
    except pymysql.MySQLError as e:
        conn.rollback()
        return jsonify(success=False, message=str(e)), 400
    finally:
        conn.close()


# ---------------------------------------------------------------
# Warehouses & inventory
# ---------------------------------------------------------------
@app.route("/api/warehouses", methods=["GET"])
def list_warehouses():
    conn = get_connection(current_role())
    try:
        with conn.cursor() as cur:
            cur.execute(
                """SELECT Warehouse_ID AS id, Warehouse_Name AS name,
                          ST_X(Location) AS lat, ST_Y(Location) AS lng
                   FROM Warehouses"""
            )
            return jsonify(cur.fetchall())
    finally:
        conn.close()


@app.route("/api/warehouses", methods=["POST"])
@require_role("Admin")
def create_warehouse():
    # Creating a warehouse does not create stock or purchases.
    # Stock enters a warehouse only through a purchase transaction.
    data = request.get_json(force=True)
    conn = get_connection(current_role())
    try:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO Warehouses (Warehouse_Name, Location) VALUES (%s, POINT(%s, %s))",
                (data["name"], data.get("lat", 0), data.get("lng", 0)),
            )
        conn.commit()
        return jsonify(success=True, id=cur.lastrowid), 201
    except pymysql.MySQLError as e:
        conn.rollback()
        return jsonify(success=False, message=str(e)), 400
    finally:
        conn.close()


@app.route("/api/inventory", methods=["GET"])
def list_inventory():
    conn = get_connection(current_role())
    try:
        with conn.cursor() as cur:
            cur.execute(
                """SELECT i.Inventory_ID AS id, i.Warehouse_ID AS warehouse_id,
                          w.Warehouse_Name AS warehouse_name, i.Product_ID AS product_id,
                          p.Product_Name AS product_name, i.Stock_Level AS stock
                   FROM Inventory i
                   JOIN Warehouses w ON w.Warehouse_ID = i.Warehouse_ID
                   JOIN Products p ON p.Product_ID = i.Product_ID"""
            )
            return jsonify(cur.fetchall())
    finally:
        conn.close()


# ---------------------------------------------------------------
# Sales & purchases -- go through the stored procedures
# ---------------------------------------------------------------
@app.route("/api/sales", methods=["GET"])
def list_sales():
    conn = get_connection(current_role())
    try:
        with conn.cursor() as cur:
            cur.execute(
                """SELECT s.Transaction_ID AS id, s.User_ID AS user_id, s.Product_ID AS product_id,
                          p.Product_Name AS product_name, s.Quantity AS quantity,
                          s.Price_Per_Product AS price
                   FROM Sales s JOIN Products p ON p.Product_ID = s.Product_ID
                   ORDER BY s.Transaction_ID DESC"""
            )
            return jsonify(cur.fetchall())
    finally:
        conn.close()


@app.route("/api/sales", methods=["POST"])
@require_role("Admin", "Staff")
def create_sale():
    data = request.get_json(force=True)
    conn = get_connection(current_role())
    try:
        with conn.cursor() as cur:
            cur.callproc(
                "InsertSale",
                (data["user_id"], data["product_id"], data["quantity"], data["warehouse_id"]),
            )
        conn.commit()
        return jsonify(success=True)
    except pymysql.MySQLError as e:
        conn.rollback()
        # e.g. the procedure's SIGNAL for insufficient stock surfaces here
        return jsonify(success=False, message=str(e)), 400
    finally:
        conn.close()


@app.route("/api/purchases", methods=["GET"])
def list_purchases():
    conn = get_connection(current_role())
    try:
        with conn.cursor() as cur:
            cur.execute(
                """SELECT pu.Transaction_ID AS id, pu.Supplier_ID AS supplier_id,
                          sp.Supplier_Name AS supplier_name, pu.Warehouse_ID AS warehouse_id,
                          w.Warehouse_Name AS warehouse_name, pu.Product_ID AS product_id,
                          p.Product_Name AS product_name, pu.Quantity AS quantity,
                          pu.Price_Per_Product AS price, pu.Transaction_Time AS transaction_time
                   FROM Purchases pu
                   JOIN Suppliers sp ON sp.Supplier_ID = pu.Supplier_ID
                   JOIN Warehouses w ON w.Warehouse_ID = pu.Warehouse_ID
                   JOIN Products p ON p.Product_ID = pu.Product_ID
                   ORDER BY pu.Transaction_ID DESC"""
            )
            return jsonify(cur.fetchall())
    finally:
        conn.close()


@app.route("/api/purchases", methods=["POST"])
@require_role("Admin", "Staff")
def create_purchase():
    data = request.get_json(force=True)
    conn = get_connection(current_role())
    try:
        with conn.cursor() as cur:
            cur.callproc("InsertPurchase", (data["supplier_id"], data["product_id"], data["quantity"], data["warehouse_id"]))
        conn.commit()
        return jsonify(success=True)
    except pymysql.MySQLError as e:
        conn.rollback()
        return jsonify(success=False, message=str(e)), 400
    finally:
        conn.close()


# ---------------------------------------------------------------
# Reports
# ---------------------------------------------------------------
@app.route("/api/reports/low-stock")
def low_stock_report():
    conn = get_connection(current_role())
    try:
        with conn.cursor() as cur:
            cur.execute(
                """SELECT Product_ID AS id, Product_Name AS name, Total_Stock AS stock,
                          Threshold AS threshold
                   FROM ProductStockSummary
                   WHERE Total_Stock <= Threshold"""
            )
            return jsonify(cur.fetchall())
    finally:
        conn.close()


# ---------------------------------------------------------------
# Serve the frontend
# ---------------------------------------------------------------
@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


if __name__ == "__main__":
    app.run(debug=True, port=5000)
