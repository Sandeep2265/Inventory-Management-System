# Database credentials, one entry per app role.
# These MUST match the MySQL users created in schema_final.sql.
# Change every password here (and in schema_final.sql) before real use.

DB_HOST = "localhost"
DB_NAME = "IMS"

DB_CONFIG = {
    "admin":   {"user": "ims_admin",   "password": "change_me_admin"},
    "staff":   {"user": "ims_staff",   "password": "change_me_staff"},
    "viewer":  {"user": "ims_viewer",  "password": "change_me_viewer"},
    "auditor": {"user": "ims_auditor", "password": "change_me_auditor"},
    "customer": {"user": "ims_customer", "password": "change_me_customer"},
}

# Used to sign Flask's session cookie. Change this to a random string.
SECRET_KEY = "replace-with-a-long-random-string"
