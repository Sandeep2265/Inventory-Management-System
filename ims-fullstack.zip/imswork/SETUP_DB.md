# IMS Database Setup

## 1. Import the corrected database

From this directory run:

```bash
sudo mysql < schema_final.sql
```

This recreates the `IMS` database.

## 2. Verify the database

```bash
sudo mysql -e "USE IMS; SHOW TABLES;"
```

You should see 10 base tables.

Check the tuple counts:

```bash
sudo mysql -e "SELECT table_name, table_rows FROM information_schema.tables WHERE table_schema='IMS' AND table_type='BASE TABLE' ORDER BY table_name;"
```

The seed data contains well over 1,000 tuples.

## 3. Configure application passwords

The schema creates these local MySQL accounts:

- `ims_admin`
- `ims_staff`
- `ims_viewer`
- `ims_auditor`

For a local demo, the passwords initially match the values in `backend/config.py`.

Run the password helper after installing backend dependencies if you want application login passwords for the `Admins` table:

```bash
cd backend
python rehash_passwords.py
```

Set the passwords interactively when prompted.

## 4. Run the application

Build the React frontend:

```bash
cd frontend-react
npm install
npm run build
```

Then start Flask:

```bash
cd ../backend
python app.py
```

The Flask server serves the React production build.

## Important DB design points for viva

- `Inventory` is the source of warehouse-level stock.
- `Products` does not store an independently mutable stock value.
- `(Warehouse_ID, Product_ID)` is unique in `Inventory`.
- Purchases increase inventory through `AfterPurchaseInsert`.
- Sales are validated by `BeforeSaleInsert` and decrease inventory through `AfterSaleInsert`.
- `InsertSale` locks the selected inventory row with `FOR UPDATE` inside a transaction.
- `InsertPurchase` performs the purchase and inventory update inside a transaction.
- Creating a warehouse does not automatically create stock or fake purchases.
- `ProductStockSummary` provides total product stock across warehouses.
- `LowStockInventory` provides warehouse-level low-stock alerts.
