# IMS — Full Stack (real MySQL + Flask + frontend)

## 1. Set up the database
```bash
mysql -u root -p < schema_final.sql
```
This creates the `IMS` database, all tables, the trigger, the two stored
procedures, the 4 role-based MySQL users, and a little seed data.

## 2. Set real passwords
The seed Admin/User rows have placeholder password hashes that won't match
anything. Set real ones:
```bash
cd backend
pip install -r requirements.txt
python rehash_passwords.py
```
This will prompt you for a password for Admin `00` and User `12` — type
whatever you want to log in with.

## 3. Run the backend
```bash
cd backend
python app.py
```
Flask serves both the API (`/api/...`) and the frontend at
`http://localhost:5000`.

## 4. Log in
Open `http://localhost:5000`, log in with Admin ID `00` and the password
you set in step 2. You'll land on the dashboard, backed entirely by MySQL —
add a product, record a sale, and watch `Stock_Level` change for real.

## Notes
- `config.py` holds the DB passwords for each role (`ims_admin`,
  `ims_staff`, `ims_viewer`, `ims_auditor`) — these must match
  `schema_final.sql`. Change all of them before using this anywhere
  but your own machine.
- Sales go through `InsertSale`, purchases through `InsertPurchase` —
  the transaction-integrity logic still lives entirely in MySQL, the
  API is just a thin pass-through.
- Only Admin/Staff can create products/sales/purchases; only Admin can
  add suppliers/warehouses or delete products. This is enforced twice:
  once in Flask (`require_role`) and again by MySQL itself, since each
  role connects as a different, separately-privileged MySQL user.

## Frontend redesign and customer portal

The React frontend now has a role-selection employee portal, separate customer login/signup, role-specific navigation, a redesigned dashboard shell, inventory search, and a customer catalog. See `CUSTOMER_PORTAL_SETUP.md` for setup.
