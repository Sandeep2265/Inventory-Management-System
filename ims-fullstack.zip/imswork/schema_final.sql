-- ============================================================
-- Inventory Management System (IMS)
-- Corrected DBMS project schema + realistic seed data
-- MySQL 8.0+
-- Run on a fresh server/database:
--     sudo mysql < schema_final.sql
-- ============================================================

DROP DATABASE IF EXISTS IMS;
CREATE DATABASE IMS CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE IMS;

-- ------------------------------------------------------------
-- 1. Roles
-- FD: Role_ID -> Role_Name
-- ------------------------------------------------------------
CREATE TABLE Roles (
    Role_ID INT AUTO_INCREMENT PRIMARY KEY,
    Role_Name VARCHAR(20) NOT NULL UNIQUE
) ENGINE=InnoDB;

INSERT INTO Roles (Role_Name) VALUES
('Admin'), ('Staff'), ('Viewer'), ('Auditor');

-- ------------------------------------------------------------
-- 2. Categories
-- ------------------------------------------------------------
CREATE TABLE Categories (
    Category_ID INT AUTO_INCREMENT PRIMARY KEY,
    Category_Name VARCHAR(70) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 3. Suppliers
-- ------------------------------------------------------------
CREATE TABLE Suppliers (
    Supplier_ID INT AUTO_INCREMENT PRIMARY KEY,
    Supplier_Name VARCHAR(100) NOT NULL,
    Phone VARCHAR(20),
    Location POINT SRID 4326 NOT NULL,
    CONSTRAINT uq_supplier_name UNIQUE (Supplier_Name),
    SPATIAL INDEX idx_supplier_location (Location)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 4. Products
-- Stock is NOT stored here as an independently mutable value.
-- Actual stock lives in Inventory(Warehouse_ID, Product_ID).
-- Total product stock is exposed through ProductStockSummary.
-- ------------------------------------------------------------
CREATE TABLE Products (
    Product_ID INT AUTO_INCREMENT PRIMARY KEY,
    Product_Name VARCHAR(100) NOT NULL UNIQUE,
    Category_ID INT NOT NULL,
    Supplier_ID INT NOT NULL,
    Restock INT NOT NULL DEFAULT 50,
    Threshold INT NOT NULL DEFAULT 20,
    Price DECIMAL(10,2) NOT NULL,
    CONSTRAINT chk_product_restock CHECK (Restock > 0),
    CONSTRAINT chk_product_threshold CHECK (Threshold >= 0),
    CONSTRAINT chk_product_price CHECK (Price >= 0),
    CONSTRAINT fk_product_category FOREIGN KEY (Category_ID)
        REFERENCES Categories(Category_ID)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_product_supplier FOREIGN KEY (Supplier_ID)
        REFERENCES Suppliers(Supplier_ID)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE INDEX idx_product_name ON Products(Product_Name);
CREATE INDEX idx_product_category ON Products(Category_ID);
CREATE INDEX idx_product_supplier ON Products(Supplier_ID);

-- ------------------------------------------------------------
-- 5. Warehouses
-- ------------------------------------------------------------
CREATE TABLE Warehouses (
    Warehouse_ID INT AUTO_INCREMENT PRIMARY KEY,
    Warehouse_Name VARCHAR(100) NOT NULL UNIQUE,
    Location POINT SRID 4326 NOT NULL,
    SPATIAL INDEX idx_warehouse_location (Location)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 6. Inventory
-- One product has exactly one stock row per warehouse.
-- FD: (Warehouse_ID, Product_ID) -> Stock_Level
-- ------------------------------------------------------------
CREATE TABLE Inventory (
    Inventory_ID INT AUTO_INCREMENT PRIMARY KEY,
    Warehouse_ID INT NOT NULL,
    Product_ID INT NOT NULL,
    Stock_Level INT NOT NULL DEFAULT 0,
    CONSTRAINT chk_inventory_stock CHECK (Stock_Level >= 0),
    CONSTRAINT uq_inventory_warehouse_product UNIQUE (Warehouse_ID, Product_ID),
    CONSTRAINT fk_inventory_warehouse FOREIGN KEY (Warehouse_ID)
        REFERENCES Warehouses(Warehouse_ID)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_inventory_product FOREIGN KEY (Product_ID)
        REFERENCES Products(Product_ID)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE INDEX idx_inventory_product ON Inventory(Product_ID);
CREATE INDEX idx_inventory_stock ON Inventory(Stock_Level);
CREATE INDEX idx_inventory_warehouse_stock ON Inventory(Warehouse_ID, Stock_Level);

-- ------------------------------------------------------------
-- 7. Users
-- Application users who perform sales / operational actions.
-- ------------------------------------------------------------
CREATE TABLE Users (
    User_ID VARCHAR(10) PRIMARY KEY,
    Name VARCHAR(80) NOT NULL,
    Email VARCHAR(120) NOT NULL UNIQUE,
    User_Password VARCHAR(255) NOT NULL,
    Address POINT SRID 4326 NOT NULL
) ENGINE=InnoDB;

CREATE INDEX idx_users_email ON Users(Email);

-- ------------------------------------------------------------
-- 8. Admins / application login identities
-- ------------------------------------------------------------
CREATE TABLE Admins (
    Admin_ID VARCHAR(10) PRIMARY KEY,
    Admin_Password VARCHAR(255) NOT NULL,
    Role_ID INT NOT NULL,
    CONSTRAINT fk_admin_role FOREIGN KEY (Role_ID)
        REFERENCES Roles(Role_ID)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE INDEX idx_admin_role ON Admins(Role_ID);

-- ------------------------------------------------------------
-- 9. Sales
-- Each sale belongs to a warehouse.
-- Stock is decreased by an AFTER INSERT trigger.
-- ------------------------------------------------------------
CREATE TABLE Sales (
    Transaction_ID INT AUTO_INCREMENT PRIMARY KEY,
    User_ID VARCHAR(10) NOT NULL,
    Warehouse_ID INT NOT NULL,
    Product_ID INT NOT NULL,
    Quantity INT NOT NULL,
    Price_Per_Product DECIMAL(10,2) NOT NULL,
    Transaction_Time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_sale_quantity CHECK (Quantity > 0),
    CONSTRAINT chk_sale_price CHECK (Price_Per_Product >= 0),
    CONSTRAINT fk_sale_user FOREIGN KEY (User_ID)
        REFERENCES Users(User_ID)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_sale_warehouse FOREIGN KEY (Warehouse_ID)
        REFERENCES Warehouses(Warehouse_ID)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_sale_product FOREIGN KEY (Product_ID)
        REFERENCES Products(Product_ID)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE INDEX idx_sales_time ON Sales(Transaction_Time);
CREATE INDEX idx_sales_product_time ON Sales(Product_ID, Transaction_Time);
CREATE INDEX idx_sales_warehouse_time ON Sales(Warehouse_ID, Transaction_Time);
CREATE INDEX idx_sales_user ON Sales(User_ID);

-- ------------------------------------------------------------
-- 10. Purchases
-- Each purchase belongs to a warehouse.
-- Stock is increased by an AFTER INSERT trigger.
-- ------------------------------------------------------------
CREATE TABLE Purchases (
    Transaction_ID INT AUTO_INCREMENT PRIMARY KEY,
    Supplier_ID INT NOT NULL,
    Warehouse_ID INT NOT NULL,
    Product_ID INT NOT NULL,
    Quantity INT NOT NULL,
    Price_Per_Product DECIMAL(10,2) NOT NULL,
    Transaction_Time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_purchase_quantity CHECK (Quantity > 0),
    CONSTRAINT chk_purchase_price CHECK (Price_Per_Product >= 0),
    CONSTRAINT fk_purchase_supplier FOREIGN KEY (Supplier_ID)
        REFERENCES Suppliers(Supplier_ID)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_warehouse FOREIGN KEY (Warehouse_ID)
        REFERENCES Warehouses(Warehouse_ID)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_product FOREIGN KEY (Product_ID)
        REFERENCES Products(Product_ID)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE INDEX idx_purchases_time ON Purchases(Transaction_Time);
CREATE INDEX idx_purchases_product_time ON Purchases(Product_ID, Transaction_Time);
CREATE INDEX idx_purchases_warehouse_time ON Purchases(Warehouse_ID, Transaction_Time);
CREATE INDEX idx_purchases_supplier ON Purchases(Supplier_ID);

-- ------------------------------------------------------------
-- Views
-- ------------------------------------------------------------
CREATE VIEW ProductStockSummary AS
SELECT
    p.Product_ID,
    p.Product_Name,
    p.Category_ID,
    c.Category_Name,
    p.Supplier_ID,
    p.Price,
    p.Restock,
    p.Threshold,
    COALESCE(SUM(i.Stock_Level), 0) AS Total_Stock
FROM Products p
JOIN Categories c ON c.Category_ID = p.Category_ID
LEFT JOIN Inventory i ON i.Product_ID = p.Product_ID
GROUP BY p.Product_ID, p.Product_Name, p.Category_ID, c.Category_Name,
         p.Supplier_ID, p.Price, p.Restock, p.Threshold;

CREATE VIEW LowStockInventory AS
SELECT
    i.Inventory_ID,
    i.Warehouse_ID,
    w.Warehouse_Name,
    i.Product_ID,
    p.Product_Name,
    i.Stock_Level,
    p.Threshold,
    p.Restock
FROM Inventory i
JOIN Warehouses w ON w.Warehouse_ID = i.Warehouse_ID
JOIN Products p ON p.Product_ID = i.Product_ID
WHERE i.Stock_Level <= p.Threshold;

CREATE VIEW SalesSummary AS
SELECT
    s.Transaction_ID,
    s.Transaction_Time,
    s.User_ID,
    s.Warehouse_ID,
    w.Warehouse_Name,
    s.Product_ID,
    p.Product_Name,
    s.Quantity,
    s.Price_Per_Product,
    s.Quantity * s.Price_Per_Product AS Total_Amount
FROM Sales s
JOIN Products p ON p.Product_ID = s.Product_ID
JOIN Warehouses w ON w.Warehouse_ID = s.Warehouse_ID;

CREATE VIEW PurchaseSummary AS
SELECT
    pu.Transaction_ID,
    pu.Transaction_Time,
    pu.Supplier_ID,
    sp.Supplier_Name,
    pu.Warehouse_ID,
    w.Warehouse_Name,
    pu.Product_ID,
    p.Product_Name,
    pu.Quantity,
    pu.Price_Per_Product,
    pu.Quantity * pu.Price_Per_Product AS Total_Amount
FROM Purchases pu
JOIN Suppliers sp ON sp.Supplier_ID = pu.Supplier_ID
JOIN Products p ON p.Product_ID = pu.Product_ID
JOIN Warehouses w ON w.Warehouse_ID = pu.Warehouse_ID;

DELIMITER $$

-- ------------------------------------------------------------
-- Trigger: validate sale stock and update inventory.
-- FOR UPDATE locking is performed in the procedure before insert.
-- ------------------------------------------------------------
CREATE TRIGGER BeforeSaleInsert
BEFORE INSERT ON Sales
FOR EACH ROW
BEGIN
    DECLARE current_stock INT DEFAULT NULL;

    SELECT Stock_Level INTO current_stock
    FROM Inventory
    WHERE Warehouse_ID = NEW.Warehouse_ID
      AND Product_ID = NEW.Product_ID
    FOR UPDATE;

    IF current_stock IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'No inventory record exists for this warehouse and product';
    END IF;

    IF current_stock < NEW.Quantity THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Insufficient stock at selected warehouse';
    END IF;
END$$

CREATE TRIGGER AfterSaleInsert
AFTER INSERT ON Sales
FOR EACH ROW
BEGIN
    UPDATE Inventory
    SET Stock_Level = Stock_Level - NEW.Quantity
    WHERE Warehouse_ID = NEW.Warehouse_ID
      AND Product_ID = NEW.Product_ID;
END$$

-- ------------------------------------------------------------
-- Trigger: purchase automatically increases inventory.
-- ------------------------------------------------------------
CREATE TRIGGER AfterPurchaseInsert
AFTER INSERT ON Purchases
FOR EACH ROW
BEGIN
    INSERT INTO Inventory (Warehouse_ID, Product_ID, Stock_Level)
    VALUES (NEW.Warehouse_ID, NEW.Product_ID, NEW.Quantity)
    ON DUPLICATE KEY UPDATE Stock_Level = Stock_Level + NEW.Quantity;
END$$

-- ------------------------------------------------------------
-- Purchase procedure.
-- One transaction protects the inventory update and purchase record.
-- ------------------------------------------------------------
CREATE PROCEDURE InsertPurchase(
    IN p_Supplier_ID INT,
    IN p_Product_ID INT,
    IN p_Quantity INT,
    IN p_Warehouse_ID INT
)
BEGIN
    DECLARE v_price DECIMAL(10,2);
    DECLARE v_supplier INT;

    IF p_Quantity <= 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Purchase quantity must be positive';
    END IF;

    START TRANSACTION;

    SELECT Price, Supplier_ID INTO v_price, v_supplier
    FROM Products
    WHERE Product_ID = p_Product_ID
    FOR UPDATE;

    IF v_price IS NULL THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Product does not exist';
    END IF;

    IF p_Supplier_ID <> v_supplier THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Supplier is not the registered supplier for this product';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM Warehouses WHERE Warehouse_ID = p_Warehouse_ID
    ) THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Warehouse does not exist';
    END IF;

    INSERT INTO Purchases
        (Supplier_ID, Warehouse_ID, Product_ID, Quantity, Price_Per_Product)
    VALUES
        (p_Supplier_ID, p_Warehouse_ID, p_Product_ID, p_Quantity, v_price);

    COMMIT;
END$$

-- ------------------------------------------------------------
-- Sale procedure.
-- Locks the exact inventory row before recording the sale.
-- No nested transaction / automatic purchase is performed here.
-- ------------------------------------------------------------
CREATE PROCEDURE InsertSale(
    IN p_User_ID VARCHAR(10),
    IN p_Product_ID INT,
    IN p_Quantity INT,
    IN p_Warehouse_ID INT
)
BEGIN
    DECLARE v_price DECIMAL(10,2);
    DECLARE v_stock INT DEFAULT NULL;

    IF p_Quantity <= 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Sale quantity must be positive';
    END IF;

    START TRANSACTION;

    SELECT Price INTO v_price
    FROM Products
    WHERE Product_ID = p_Product_ID
    FOR UPDATE;

    IF v_price IS NULL THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Product does not exist';
    END IF;

    SELECT Stock_Level INTO v_stock
    FROM Inventory
    WHERE Warehouse_ID = p_Warehouse_ID
      AND Product_ID = p_Product_ID
    FOR UPDATE;

    IF v_stock IS NULL THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'No inventory record exists for selected warehouse';
    END IF;

    IF v_stock < p_Quantity THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Insufficient stock at selected warehouse';
    END IF;

    INSERT INTO Sales
        (User_ID, Warehouse_ID, Product_ID, Quantity, Price_Per_Product)
    VALUES
        (p_User_ID, p_Warehouse_ID, p_Product_ID, p_Quantity, v_price);

    COMMIT;
END$$

DELIMITER ;

-- ------------------------------------------------------------
-- DB-level access control
-- ------------------------------------------------------------
CREATE USER IF NOT EXISTS 'ims_admin'@'localhost' IDENTIFIED BY 'change_me_admin';
CREATE USER IF NOT EXISTS 'ims_staff'@'localhost' IDENTIFIED BY 'change_me_staff';
CREATE USER IF NOT EXISTS 'ims_viewer'@'localhost' IDENTIFIED BY 'change_me_viewer';
CREATE USER IF NOT EXISTS 'ims_auditor'@'localhost' IDENTIFIED BY 'change_me_auditor';

GRANT ALL PRIVILEGES ON IMS.* TO 'ims_admin'@'localhost';

GRANT SELECT ON IMS.Roles TO 'ims_staff'@'localhost';
GRANT SELECT, INSERT, UPDATE ON IMS.Categories TO 'ims_staff'@'localhost';
GRANT SELECT, INSERT, UPDATE ON IMS.Products TO 'ims_staff'@'localhost';
GRANT SELECT ON IMS.Suppliers TO 'ims_staff'@'localhost';
GRANT SELECT ON IMS.Warehouses TO 'ims_staff'@'localhost';
GRANT SELECT ON IMS.Inventory TO 'ims_staff'@'localhost';
GRANT SELECT, INSERT ON IMS.Sales TO 'ims_staff'@'localhost';
GRANT SELECT, INSERT ON IMS.Purchases TO 'ims_staff'@'localhost';
GRANT SELECT ON IMS.Users TO 'ims_staff'@'localhost';
GRANT EXECUTE ON PROCEDURE IMS.InsertSale TO 'ims_staff'@'localhost';
GRANT EXECUTE ON PROCEDURE IMS.InsertPurchase TO 'ims_staff'@'localhost';
GRANT SELECT ON IMS.ProductStockSummary TO 'ims_staff'@'localhost';
GRANT SELECT ON IMS.LowStockInventory TO 'ims_staff'@'localhost';
GRANT SELECT ON IMS.SalesSummary TO 'ims_staff'@'localhost';
GRANT SELECT ON IMS.PurchaseSummary TO 'ims_staff'@'localhost';

GRANT SELECT ON IMS.Roles TO 'ims_viewer'@'localhost';
GRANT SELECT ON IMS.Categories TO 'ims_viewer'@'localhost';
GRANT SELECT ON IMS.Products TO 'ims_viewer'@'localhost';
GRANT SELECT ON IMS.Suppliers TO 'ims_viewer'@'localhost';
GRANT SELECT ON IMS.Warehouses TO 'ims_viewer'@'localhost';
GRANT SELECT ON IMS.Inventory TO 'ims_viewer'@'localhost';
GRANT SELECT ON IMS.ProductStockSummary TO 'ims_viewer'@'localhost';
GRANT SELECT ON IMS.LowStockInventory TO 'ims_viewer'@'localhost';

GRANT SELECT ON IMS.Roles TO 'ims_auditor'@'localhost';
GRANT SELECT ON IMS.Products TO 'ims_auditor'@'localhost';
GRANT SELECT ON IMS.Inventory TO 'ims_auditor'@'localhost';
GRANT SELECT ON IMS.Sales TO 'ims_auditor'@'localhost';
GRANT SELECT ON IMS.Purchases TO 'ims_auditor'@'localhost';
GRANT SELECT ON IMS.SalesSummary TO 'ims_auditor'@'localhost';
GRANT SELECT ON IMS.PurchaseSummary TO 'ims_auditor'@'localhost';
GRANT SELECT ON IMS.Warehouses TO 'ims_auditor'@'localhost';
GRANT SELECT ON IMS.Suppliers TO 'ims_auditor'@'localhost';

FLUSH PRIVILEGES;

-- ------------------------------------------------------------
-- Seed data: > 1,000 realistic tuples.
-- The generated records are deterministic and internally linked.
-- ------------------------------------------------------------

INSERT INTO Categories (Category_Name) VALUES
('Laptops'), ('Smartphones'), ('Audio'), ('Computer Accessories'),
('Monitors'), ('Networking'), ('Storage'), ('Printers'),
('Cameras'), ('Power Accessories'), ('Tablets'), ('Wearables'),
('Gaming'), ('Office Equipment'), ('Cables'), ('Components'),
('Security'), ('Smart Home'), ('POS Equipment'), ('Miscellaneous');

INSERT INTO Suppliers (Supplier_Name, Phone, Location) VALUES
('TechSource India', '+91-9000000001', ST_SRID(POINT(78.4867,17.3850),4326)),
('Digital Wholesale Co', '+91-9000000002', ST_SRID(POINT(77.5946,12.9716),4326)),
('Metro Electronics', '+91-9000000003', ST_SRID(POINT(72.8777,19.0760),4326)),
('Prime Components', '+91-9000000004', ST_SRID(POINT(80.2707,13.0827),4326)),
('Smart Retail Supply', '+91-9000000005', ST_SRID(POINT(88.3639,22.5726),4326)),
('National Devices', '+91-9000000006', ST_SRID(POINT(28.6139,77.2090),4326)),
('SouthTech Distributors', '+91-9000000007', ST_SRID(POINT(76.9558,11.0168),4326)),
('WestZone Electronics', '+91-9000000008', ST_SRID(POINT(73.8567,18.5204),4326)),
('CloudNine Hardware', '+91-9000000009', ST_SRID(POINT(17.6599,78.5600),4326)),
('Reliable Supplies', '+91-9000000010', ST_SRID(POINT(78.0322,30.3165),4326)),
('Vertex Distribution', '+91-9000000011', ST_SRID(POINT(77.4126,23.2599),4326)),
('Apex Office Systems', '+91-9000000012', ST_SRID(POINT(75.7873,26.9124),4326)),
('Brightline Traders', '+91-9000000013', ST_SRID(POINT(85.8245,20.2961),4326)),
('NextGen Retail', '+91-9000000014', ST_SRID(POINT(80.6480,16.5062),4326)),
('Universal Tech Mart', '+91-9000000015', ST_SRID(POINT(74.1240,15.2993),4326)),
('Enterprise Hardware Ltd', '+91-9000000016', ST_SRID(POINT(79.0882,21.1458),4326)),
('CoreLink Systems', '+91-9000000017', ST_SRID(POINT(82.9739,25.3176),4326)),
('BluePeak Electronics', '+91-9000000018', ST_SRID(POINT(73.0479,26.2389),4326)),
('Greenfield Devices', '+91-9000000019', ST_SRID(POINT(79.0882,21.1458),4326)),
('RapidStock Solutions', '+91-9000000020', ST_SRID(POINT(77.2167,31.1048),4326));

INSERT INTO Warehouses (Warehouse_Name, Location) VALUES
('Hyderabad Central', ST_SRID(POINT(78.4867,17.3850),4326)),
('Bengaluru Hub', ST_SRID(POINT(77.5946,12.9716),4326)),
('Chennai Hub', ST_SRID(POINT(80.2707,13.0827),4326)),
('Mumbai Hub', ST_SRID(POINT(72.8777,19.0760),4326)),
('Delhi NCR Hub', ST_SRID(POINT(77.2090,28.6139),4326)),
('Kolkata Hub', ST_SRID(POINT(88.3639,22.5726),4326)),
('Pune Hub', ST_SRID(POINT(73.8567,18.5204),4326)),
('Coimbatore Hub', ST_SRID(POINT(76.9558,11.0168),4326)),
('Vijayawada Hub', ST_SRID(POINT(80.6480,16.5062),4326)),
('Jaipur Hub', ST_SRID(POINT(75.7873,26.9124),4326));

INSERT INTO Users (User_ID, Name, Email, User_Password, Address) VALUES
('U001','Aarav Sharma','aarav@example.com','pbkdf2:sha256:600000$placeholder',ST_SRID(POINT(78.4867,17.3850),4326)),
('U002','Diya Reddy','diya@example.com','pbkdf2:sha256:600000$placeholder',ST_SRID(POINT(77.5946,12.9716),4326)),
('U003','Arjun Kumar','arjun@example.com','pbkdf2:sha256:600000$placeholder',ST_SRID(POINT(80.2707,13.0827),4326)),
('U004','Ananya Rao','ananya@example.com','pbkdf2:sha256:600000$placeholder',ST_SRID(POINT(72.8777,19.0760),4326)),
('U005','Rohan Patel','rohan@example.com','pbkdf2:sha256:600000$placeholder',ST_SRID(POINT(77.2090,28.6139),4326)),
('U006','Meera Singh','meera@example.com','pbkdf2:sha256:600000$placeholder',ST_SRID(POINT(88.3639,22.5726),4326)),
('U007','Vikram Das','vikram@example.com','pbkdf2:sha256:600000$placeholder',ST_SRID(POINT(73.8567,18.5204),4326)),
('U008','Kavya Nair','kavya@example.com','pbkdf2:sha256:600000$placeholder',ST_SRID(POINT(76.9558,11.0168),4326)),
('U009','Rahul Verma','rahul@example.com','pbkdf2:sha256:600000$placeholder',ST_SRID(POINT(80.6480,16.5062),4326)),
('U010','Ishita Jain','ishita@example.com','pbkdf2:sha256:600000$placeholder',ST_SRID(POINT(75.7873,26.9124),4326));

INSERT INTO Admins (Admin_ID, Admin_Password, Role_ID) VALUES
('00','pbkdf2:sha256:600000$placeholder',(SELECT Role_ID FROM Roles WHERE Role_Name='Admin')),
('01','pbkdf2:sha256:600000$placeholder',(SELECT Role_ID FROM Roles WHERE Role_Name='Staff')),
('02','pbkdf2:sha256:600000$placeholder',(SELECT Role_ID FROM Roles WHERE Role_Name='Viewer')),
('03','pbkdf2:sha256:600000$placeholder',(SELECT Role_ID FROM Roles WHERE Role_Name='Auditor'));

-- 300 products
DELIMITER $$
CREATE PROCEDURE SeedProducts()
BEGIN
    DECLARE n INT DEFAULT 1;
    DECLARE cat INT;
    DECLARE sup INT;
    DECLARE price DECIMAL(10,2);

    WHILE n <= 300 DO
        SET cat = ((n - 1) MOD 20) + 1;
        SET sup = ((n - 1) MOD 20) + 1;
        SET price = 15.00 + ((n * 37) MOD 150000) / 100.0;

        INSERT INTO Products
            (Product_Name, Category_ID, Supplier_ID, Restock, Threshold, Price)
        VALUES
            (CONCAT('Product-', LPAD(n,3,'0')),
             cat, sup,
             30 + (n MOD 70),
             10 + (n MOD 30),
             price);

        SET n = n + 1;
    END WHILE;
END$$
DELIMITER ;
CALL SeedProducts();
DROP PROCEDURE SeedProducts;

-- ------------------------------------------------------------
-- Seed inventory, purchases and sales.
-- The seed data is set-based and uses actual primary keys from the
-- tables instead of assuming that IDs are contiguous.
-- ------------------------------------------------------------

-- Create one inventory row for every product/warehouse pair.
-- Initial stock is zero; purchases below establish the current stock.
INSERT INTO Inventory (Warehouse_ID, Product_ID, Stock_Level)
SELECT
    w.Warehouse_ID,
    p.Product_ID,
    0
FROM Warehouses w
CROSS JOIN Products p;

-- 3,000 purchases: one purchase for every product/warehouse pair.
-- The registered supplier for each product is used, and Price is read
-- directly from Products, so Price_Per_Product can never be NULL.
INSERT INTO Purchases
    (Supplier_ID, Warehouse_ID, Product_ID, Quantity,
     Price_Per_Product, Transaction_Time)
SELECT
    p.Supplier_ID,
    w.Warehouse_ID,
    p.Product_ID,
    50 + MOD(p.Product_ID * 13 + w.Warehouse_ID * 7, 101),
    p.Price,
    TIMESTAMP(
        DATE_SUB(CURDATE(), INTERVAL MOD(p.Product_ID * 3 + w.Warehouse_ID, 180) DAY),
        MAKETIME(
            8 + MOD(p.Product_ID, 9),
            MOD(p.Product_ID * 7 + w.Warehouse_ID, 60),
            0
        )
    )
FROM Products p
CROSS JOIN Warehouses w;

-- 1,000 sales. Each selected product/warehouse pair already has stock
-- from the purchase above, so the sale trigger can safely validate it.
INSERT INTO Sales
    (User_ID, Warehouse_ID, Product_ID, Quantity,
     Price_Per_Product, Transaction_Time)
SELECT
    u.User_ID,
    x.Warehouse_ID,
    x.Product_ID,
    1 + MOD(x.Product_ID * 5 + x.Warehouse_ID, 5),
    p.Price,
    TIMESTAMP(
        DATE_SUB(CURDATE(), INTERVAL MOD(x.Product_ID * 2 + x.Warehouse_ID, 150) DAY),
        MAKETIME(
            9 + MOD(x.Product_ID, 8),
            MOD(x.Product_ID * 11 + x.Warehouse_ID, 60),
            0
        )
    )
FROM (
    SELECT
        w.Warehouse_ID,
        p.Product_ID,
        ROW_NUMBER() OVER (ORDER BY w.Warehouse_ID, p.Product_ID) AS rn
    FROM Warehouses w
    CROSS JOIN Products p
) x
JOIN Products p ON p.Product_ID = x.Product_ID
JOIN Users u ON u.User_ID = CONCAT('U', LPAD(MOD(x.rn - 1, 10) + 1, 3, '0'))
WHERE x.rn <= 1000;

-- Make the database statistics easy to verify after import.
ANALYZE TABLE Roles, Categories, Suppliers, Products, Warehouses,
    Inventory, Users, Admins, Sales, Purchases;

FLUSH PRIVILEGES;

-- ============================================================
-- Expected base-table tuple counts are comfortably above 1,000.
-- ============================================================
