async function request(path, options = {}) {
  const res = await fetch(`/api${path}`, { headers:{"Content-Type":"application/json"}, credentials:"same-origin", ...options });
  const data = await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.message || `Request failed (${res.status})`);
  return data;
}
export const api={
 login:(id,password,role)=>request("/login",{method:"POST",body:JSON.stringify({id,password,expected_role:role})}),
 customerLogin:(email,password)=>request("/customer/login",{method:"POST",body:JSON.stringify({email,password})}),
 signupCustomer:(p)=>request("/customer/signup",{method:"POST",body:JSON.stringify(p)}),
 logout:()=>request("/logout",{method:"POST"}), me:()=>request("/me"),
 getProducts:()=>request("/products"),addProduct:p=>request("/products",{method:"POST",body:JSON.stringify(p)}),updateProduct:(id,p)=>request(`/products/${id}`,{method:"PUT",body:JSON.stringify(p)}),deleteProduct:id=>request(`/products/${id}`,{method:"DELETE"}),
 getCategories:()=>request("/categories"),addCategory:c=>request("/categories",{method:"POST",body:JSON.stringify(c)}),getSuppliers:()=>request("/suppliers"),addSupplier:s=>request("/suppliers",{method:"POST",body:JSON.stringify(s)}),getWarehouses:()=>request("/warehouses"),addWarehouse:w=>request("/warehouses",{method:"POST",body:JSON.stringify(w)}),
 getInventory:()=>request("/inventory"),getSales:()=>request("/sales"),addSale:s=>request("/sales",{method:"POST",body:JSON.stringify(s)}),getPurchases:()=>request("/purchases"),addPurchase:p=>request("/purchases",{method:"POST",body:JSON.stringify(p)}),getLowStock:()=>request("/reports/low-stock")
};
