import {useEffect,useState} from "react";
import {api} from "./api.js";
import Login from "./components/Login.jsx";
import CustomerAuth from "./components/CustomerAuth.jsx";
import Sidebar from "./components/Sidebar.jsx";
import Dashboard from "./components/Dashboard.jsx";
import Products from "./components/Products.jsx";
import Categories from "./components/Categories.jsx";
import Suppliers from "./components/Suppliers.jsx";
import Warehouses from "./components/Warehouses.jsx";
import Inventory from "./components/Inventory.jsx";
import Sales from "./components/Sales.jsx";
import Purchases from "./components/Purchases.jsx";
import Reports from "./components/Reports.jsx";
import CustomerDashboard from "./components/CustomerDashboard.jsx";
const P={dashboard:Dashboard,products:Products,categories:Categories,suppliers:Suppliers,warehouses:Warehouses,inventory:Inventory,sales:Sales,purchases:Purchases,reports:Reports};
export default function App(){const [session,setSession]=useState(null);const [checked,setChecked]=useState(false);const [authMode,setAuthMode]=useState("landing");const [page,setPage]=useState("dashboard");useEffect(()=>{api.me().then(r=>{if(r.logged_in)setSession({id:r.id,name:r.name,role:r.role,accountType:r.account_type});}).finally(()=>setChecked(true));},[]);async function logout(){await api.logout();setSession(null);setAuthMode("landing");setPage("dashboard");}if(!checked)return <div className="loading-screen"><div className="brand-mark">IMS</div><span>Loading workspace…</span></div>;if(!session){if(authMode==="employee"||authMode==="landing")return <Login onLoggedIn={setSession} onCustomer={setAuthMode} />;return <CustomerAuth mode={authMode} setMode={setAuthMode} onLoggedIn={setSession}/>;}if(session.accountType==="customer")return <CustomerDashboard session={session} onLogout={logout}/>;const C=P[page]||Dashboard;return <div className="app"><Sidebar page={page} setPage={setPage} role={session.role} session={session} onLogout={logout}/><main className="content"><div className="topbar"><div><span className="live-dot"/> Database connected</div><div className="top-role">{session.id} · {session.role}</div></div><C role={session.role}/></main></div>}
