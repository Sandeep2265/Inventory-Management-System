import { useEffect, useState } from "react";
import { api } from "../api.js";
import Modal from "./Modal.jsx";

export default function Purchases({ role }) {
  const [purchases, setPurchases] = useState([]);
  const [products, setProducts] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [warehouses, setWarehouses] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ supplier_id: "", product_id: "", warehouse_id: "", quantity: "" });
  const [error, setError] = useState("");
  const canEdit = role === "Admin" || role === "Staff";

  async function load() { setPurchases(await api.getPurchases()); }
  useEffect(() => {
    load();
    if (canEdit) Promise.all([api.getProducts(), api.getSuppliers(), api.getWarehouses()]).then(([p, s, w]) => { setProducts(p); setSuppliers(s); setWarehouses(w); });
  }, []);

  async function handleAdd(e) {
    e.preventDefault();
    try {
      await api.addPurchase({
        supplier_id: +form.supplier_id, product_id: +form.product_id, warehouse_id: +form.warehouse_id, quantity: +form.quantity,
      });
      setShowForm(false); setForm({ supplier_id: "", product_id: "", warehouse_id: "", quantity: "" }); load();
    } catch (err) { setError(err.message); }
  }

  return (
    <section className="page active">
      <div className="page-header">
        <h1>Purchases</h1>
        {canEdit && <button className="btn-primary" onClick={() => setShowForm(true)}>+ Record Purchase</button>}
      </div>
      <table>
        <thead><tr><th>ID</th><th>Supplier</th><th>Warehouse</th><th>Product</th><th>Qty</th><th>Price</th></tr></thead>
        <tbody>
          {purchases.length === 0 && <tr><td colSpan="6">No purchases yet</td></tr>}
          {purchases.map((p) => (
            <tr key={p.id}><td>#{p.id}</td><td>{p.supplier_name}</td><td>{p.warehouse_name}</td><td>{p.product_name}</td><td>{p.quantity}</td><td>₹{Number(p.price).toLocaleString()}</td></tr>
          ))}
        </tbody>
      </table>

      {showForm && (
        <Modal title="Record Purchase" onClose={() => setShowForm(false)}>
          <form onSubmit={handleAdd}>
            <label>Supplier</label>
            <select value={form.supplier_id} onChange={(e) => setForm({ ...form, supplier_id: e.target.value })} required>
              <option value="">Select...</option>
              {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <label>Product</label>
            <select value={form.product_id} onChange={(e) => setForm({ ...form, product_id: e.target.value })} required>
              <option value="">Select...</option>
              {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <label>Warehouse</label>
            <select value={form.warehouse_id} onChange={(e) => setForm({ ...form, warehouse_id: e.target.value })} required>
              <option value="">Select...</option>
              {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
            </select>
            <label>Quantity</label>
            <input type="number" min="1" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} required />
            <p className="error-text">{error}</p>
            <button type="submit">Save</button>
          </form>
        </Modal>
      )}
    </section>
  );
}
