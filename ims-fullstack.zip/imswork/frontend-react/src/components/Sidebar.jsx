const ALL = [
  ["dashboard","⌂","Dashboard"],["products","▣","Products"],["categories","◈","Categories"],["inventory","▥","Inventory"],["suppliers","♙","Suppliers"],["warehouses","⌗","Warehouses"],["sales","↗","Sales"],["purchases","↙","Purchases"],["reports","▤","Reports"]
];
const ACCESS={Admin:ALL,Staff:ALL.filter(x=>["dashboard","products","categories","inventory","sales","purchases","reports"].includes(x[0])),Viewer:ALL.filter(x=>["dashboard","products","categories","inventory","reports"].includes(x[0])),Auditor:ALL.filter(x=>["dashboard","inventory","products","suppliers","warehouses","sales","purchases","reports"].includes(x[0]))};
export default function Sidebar({page,setPage,role,onLogout,session}){
 const items=ACCESS[role]||[];
 return <aside className="sidebar"><div className="sidebar-brand"><div className="brand-mark">IMS</div><div><strong>Inventory OS</strong><small>Management Suite</small></div></div><div className="role-chip"><span className="role-dot"/> {role} <span className="verified">✓</span></div><nav>{items.map(([key,icon,label])=><button key={key} className={`nav-link ${page===key?"active":""}`} onClick={()=>setPage(key)}><span>{icon}</span>{label}</button>)}</nav><div className="sidebar-user"><div className="avatar">{(session?.id||"U").slice(-1)}</div><div><strong>{session?.id || "User"}</strong><small>{role} account</small></div></div><button className="logout" onClick={onLogout}>↪ <span>Sign out</span></button></aside>;
}
