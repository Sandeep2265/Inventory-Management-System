import { useEffect, useState } from "react";
import { api } from "../api.js";

export default function Dashboard() {
  const [stats, setStats] = useState({ products: 0, value: 0, lowStock: 0, suppliers: 0 });

  useEffect(() => {
    (async () => {
      const [products, suppliers, lowStock] = await Promise.all([
        api.getProducts(), api.getSuppliers(), api.getLowStock(),
      ]);
      setStats({
        products: products.length,
        value: products.reduce((sum, p) => sum + p.stock * p.price, 0),
        lowStock: lowStock.length,
        suppliers: suppliers.length,
      });
    })();
  }, []);

  return (
    <section className="page active">
      <h1>Dashboard</h1>
      <div className="cards">
        <div className="stat-card"><h3>{stats.products}</h3><p>Products</p></div>
        <div className="stat-card"><h3>₹{stats.value.toLocaleString()}</h3><p>Inventory Value</p></div>
        <div className="stat-card"><h3>{stats.lowStock}</h3><p>Low Stock Items</p></div>
        <div className="stat-card"><h3>{stats.suppliers}</h3><p>Suppliers</p></div>
      </div>
    </section>
  );
}
