import { useState } from "react";
import { api } from "../api.js";

export default function CustomerAuth({ mode, setMode, onLoggedIn }) {
  const [form, setForm] = useState({ name:"", email:"", password:"", confirm:"", lat:"", lng:"" });
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const update = (k,v) => setForm(f => ({...f,[k]:v}));

  async function submit(e) {
    e.preventDefault(); setError(""); setMessage("");
    try {
      if (mode === "signup") {
        if (form.password !== form.confirm) throw new Error("Passwords do not match");
        const res = await api.signupCustomer({ name:form.name, email:form.email, password:form.password, lat:Number(form.lat || 0), lng:Number(form.lng || 0) });
        setMessage(`Account created successfully. Your Customer ID is ${res.id}.`);
        setForm({name:"",email:"",password:"",confirm:"",lat:"",lng:""});
        return;
      }
      const res = await api.customerLogin(form.email, form.password);
      onLoggedIn({ role:"Customer", id:res.id, name:res.name, accountType:"customer" });
    } catch (err) { setError(err.message); }
  }

  return <div className="auth-shell compact-auth">
    <div className="auth-panel auth-full">
      <div className="auth-form-wrap">
        <button className="back-button" onClick={() => setMode("landing")}>← Back</button>
        <div className="brand-mark small">IMS</div>
        <p className="eyebrow">CUSTOMER PORTAL</p>
        <h2>{mode === "signup" ? "Create your account" : "Customer login"}</h2>
        <p className="muted">{mode === "signup" ? "Create a customer account for the IMS system." : "Sign in to access your customer profile."}</p>
        <form onSubmit={submit} className="modern-form">
          {mode === "signup" && <label>Full name<input value={form.name} onChange={e=>update("name",e.target.value)} placeholder="Your name" required /></label>}
          <label>Email<input type="email" value={form.email} onChange={e=>update("email",e.target.value)} placeholder="you@example.com" required /></label>
          <label>Password<input type="password" value={form.password} onChange={e=>update("password",e.target.value)} required /></label>
          {mode === "signup" && <>
            <label>Confirm password<input type="password" value={form.confirm} onChange={e=>update("confirm",e.target.value)} required /></label>
            <div className="two-col"><label>Latitude <input type="number" step="0.0001" value={form.lat} onChange={e=>update("lat",e.target.value)} placeholder="Optional" /></label><label>Longitude <input type="number" step="0.0001" value={form.lng} onChange={e=>update("lng",e.target.value)} placeholder="Optional" /></label></div>
          </>}
          {error && <div className="form-error">{error}</div>}
          {message && <div className="form-success">{message}</div>}
          <button className="primary-action" type="submit">{mode === "signup" ? "Create account" : "Sign in"} <span>→</span></button>
        </form>
        <button className="text-button" onClick={() => { setMode(mode === "signup" ? "customer" : "signup"); setError(""); setMessage(""); }}>{mode === "signup" ? "Already have an account? Sign in" : "New customer? Create an account"}</button>
      </div>
    </div>
  </div>;
}
