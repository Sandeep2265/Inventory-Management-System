import { useEffect, useState } from "react";
import { api } from "../api.js";
import Modal from "./Modal.jsx";

export default function Sales({ role }) {
  const [sales, setSales] = useState([]);
  const [products, setProducts] = useState([]);
  const [warehouses, setWarehouses] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ user_id: "", product_id: "", warehouse_id: "", quantity: "" });
  const [error, setError] = useState("");
  const canEdit = role === "Admin" || role === "Staff";

  async function load() { setSales(await api.getSales()); }
  useEffect(() => {
    load();
    if (canEdit) Promise.all([api.getProducts(), api.getWarehouses()]).then(([p, w]) => { setProducts(p); setWarehouses(w); });
  }, []);

  async function handleAdd(e) {
    e.preventDefault();
    try {
      // Goes straight to the InsertSale stored procedure -- stock checks,
      // the update, and auto-reorder logic all happen inside MySQL.
      await api.addSale({
        user_id: form.user_id, product_id: +form.product_id,
        warehouse_id: +form.warehouse_id, quantity: +form.quantity,
      });
      setShowForm(false); setForm({ user_id: "", product_id: "", warehouse_id: "", quantity: "" }); load();
    } catch (err) { setError(err.message); }
  }

  return (
    <section className="page active">
      <div className="page-header">
        <h1>Sales</h1>
        {canEdit && <button className="btn-primary" onClick={() => setShowForm(true)}>+ Record Sale</button>}
      </div>
      <table>
        <thead><tr><th>ID</th><th>User</th><th>Product</th><th>Qty</th><th>Price</th></tr></thead>
        <tbody>
          {sales.length === 0 && <tr><td colSpan="5">No sales yet</td></tr>}
          {sales.map((s) => (
            <tr key={s.id}><td>#{s.id}</td><td>{s.user_id}</td><td>{s.product_name}</td><td>{s.quantity}</td><td>₹{s.price}</td></tr>
          ))}
        </tbody>
      </table>

      {showForm && (
        <Modal title="Record Sale" onClose={() => setShowForm(false)}>
          <form onSubmit={handleAdd}>
            <label>User ID</label>
            <input value={form.user_id} onChange={(e) => setForm({ ...form, user_id: e.target.value })} required />
            <label>Product</label>
            <select value={form.product_id} onChange={(e) => setForm({ ...form, product_id: e.target.value })} required>
              <option value="">Select...</option>
              {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <label>Warehouse</label>
            <select value={form.warehouse_id} onChange={(e) => setForm({ ...form, warehouse_id: e.target.value })} required>
              <option value="">Select...</option>
              {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
            </select>
            <label>Quantity</label>
            <input type="number" min="1" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} required />
            <p className="error-text">{error}</p>
            <button type="submit">Save</button>
          </form>
        </Modal>
      )}
    </section>
  );
}
