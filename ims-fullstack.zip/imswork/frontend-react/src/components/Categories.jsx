import { useEffect, useState } from "react";
import { api } from "../api.js";
import Modal from "./Modal.jsx";

export default function Categories({ role }) {
  const [categories, setCategories] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const canEdit = role === "Admin" || role === "Staff";

  async function load() { setCategories(await api.getCategories()); }
  useEffect(() => { load(); }, []);

  async function handleAdd(e) {
    e.preventDefault();
    try {
      await api.addCategory({ name });
      setShowForm(false); setName(""); load();
    } catch (err) { setError(err.message); }
  }

  return (
    <section className="page active">
      <div className="page-header">
        <h1>Categories</h1>
        {canEdit && <button className="btn-primary" onClick={() => setShowForm(true)}>+ Add Category</button>}
      </div>
      <div className="card-grid">
        {categories.length === 0 && <p>No categories yet</p>}
        {categories.map((c) => <div key={c.id} className="category-card"><h4>{c.name}</h4></div>)}
      </div>

      {showForm && (
        <Modal title="Add Category" onClose={() => setShowForm(false)}>
          <form onSubmit={handleAdd}>
            <label>Name</label>
            <input value={name} onChange={(e) => setName(e.target.value)} required />
            <p className="error-text">{error}</p>
            <button type="submit">Save</button>
          </form>
        </Modal>
      )}
    </section>
  );
}
