import { useEffect, useState } from "react";
import { api } from "../api.js";
export default function Inventory(){
 const [items,setItems]=useState([]); const [q,setQ]=useState("");
 useEffect(()=>{api.getInventory().then(setItems).catch(()=>setItems([]));},[]);
 const filtered=items.filter(x=>`${x.product_name} ${x.warehouse_name}`.toLowerCase().includes(q.toLowerCase()));
 return <section className="page active"><div className="page-header"><div><p className="eyebrow">STOCK CONTROL</p><h1>Inventory</h1><p className="muted">Real-time stock across all warehouses.</p></div><div className="search-box">⌕<input placeholder="Search product or warehouse" value={q} onChange={e=>setQ(e.target.value)}/></div></div><div className="table-card"><table><thead><tr><th>Product</th><th>Warehouse</th><th>Stock</th><th>Status</th></tr></thead><tbody>{filtered.map(i=><tr key={i.id}><td><strong>{i.product_name}</strong><small className="table-sub">Product #{i.product_id}</small></td><td>{i.warehouse_name}</td><td><strong>{i.stock}</strong></td><td><span className="status-pill ok">Available</span></td></tr>)}</tbody></table></div></section>;
}
