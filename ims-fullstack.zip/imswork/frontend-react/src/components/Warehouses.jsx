import { useEffect, useState } from "react";
import { api } from "../api.js";
import Modal from "./Modal.jsx";

export default function Warehouses({ role }) {
  const [warehouses, setWarehouses] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", lat: 0, lng: 0 });
  const [error, setError] = useState("");
  const canEdit = role === "Admin";

  async function load() { setWarehouses(await api.getWarehouses()); }
  useEffect(() => { load(); }, []);

  async function handleAdd(e) {
    e.preventDefault();
    try {
      // Inserting fires the AddInventory trigger server-side: every
      // existing product gets stocked here automatically.
      await api.addWarehouse({ ...form, lat: +form.lat, lng: +form.lng });
      setShowForm(false); setForm({ name: "", lat: 0, lng: 0 }); load();
    } catch (err) { setError(err.message); }
  }

  return (
    <section className="page active">
      <div className="page-header">
        <h1>Warehouses</h1>
        {canEdit && <button className="btn-primary" onClick={() => setShowForm(true)}>+ Add Warehouse</button>}
      </div>
      <table>
        <thead><tr><th>ID</th><th>Name</th></tr></thead>
        <tbody>
          {warehouses.length === 0 && <tr><td colSpan="2">No warehouses yet</td></tr>}
          {warehouses.map((w) => <tr key={w.id}><td>#{w.id}</td><td>{w.name}</td></tr>)}
        </tbody>
      </table>

      {showForm && (
        <Modal title="Add Warehouse" onClose={() => setShowForm(false)}>
          <form onSubmit={handleAdd}>
            <label>Name</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
            <label>Latitude</label>
            <input type="number" step="0.0001" value={form.lat} onChange={(e) => setForm({ ...form, lat: e.target.value })} />
            <label>Longitude</label>
            <input type="number" step="0.0001" value={form.lng} onChange={(e) => setForm({ ...form, lng: e.target.value })} />
            <p className="error-text">{error}</p>
            <button type="submit">Save</button>
          </form>
        </Modal>
      )}
    </section>
  );
}
