import { useEffect, useState } from "react";
import { api } from "../api.js";
import Modal from "./Modal.jsx";

export default function Products({ role }) {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", category_id: "", supplier_id: "", price: "" });
  const [error, setError] = useState("");

  const canEdit = role === "Admin" || role === "Staff";

  async function load() {
    const [p, c, s] = await Promise.all([api.getProducts(), api.getCategories(), api.getSuppliers()]);
    setProducts(p); setCategories(c); setSuppliers(s);
  }

  useEffect(() => { load(); }, []);

  async function handleAdd(e) {
    e.preventDefault();
    try {
      await api.addProduct({
        name: form.name,
        category_id: +form.category_id,
        supplier_id: +form.supplier_id,
        price: +form.price,
      });
      setShowForm(false);
      setForm({ name: "", category_id: "", supplier_id: "", price: "" });
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleDelete(id) {
    if (!confirm("Delete this product?")) return;
    try { await api.deleteProduct(id); load(); } catch (err) { alert(err.message); }
  }

  return (
    <section className="page active">
      <div className="page-header">
        <h1>Products</h1>
        {canEdit && <button className="btn-primary" onClick={() => setShowForm(true)}>+ Add Product</button>}
      </div>
      <table>
        <thead>
          <tr><th>ID</th><th>Name</th><th>Category</th><th>Supplier</th><th>Stock</th><th>Price</th><th>Status</th>{canEdit && <th>Actions</th>}</tr>
        </thead>
        <tbody>
          {products.length === 0 && <tr><td colSpan="8">No products yet</td></tr>}
          {products.map((p) => {
            const cat = categories.find((c) => c.id === p.category_id);
            const sup = suppliers.find((s) => s.id === p.supplier_id);
            const low = p.stock <= p.threshold;
            return (
              <tr key={p.id}>
                <td>#{p.id}</td><td>{p.name}</td><td>{cat?.name || "-"}</td><td>{sup?.name || "-"}</td>
                <td>{p.stock}</td><td>₹{Number(p.price).toLocaleString()}</td>
                <td className={low ? "status-low" : "status-ok"}>{low ? "Low" : "OK"}</td>
                {canEdit && <td><button onClick={() => handleDelete(p.id)}>Delete</button></td>}
              </tr>
            );
          })}
        </tbody>
      </table>

      {showForm && (
        <Modal title="Add Product" onClose={() => setShowForm(false)}>
          <form onSubmit={handleAdd}>
            <label>Name</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
            <label>Category</label>
            <select value={form.category_id} onChange={(e) => setForm({ ...form, category_id: e.target.value })} required>
              <option value="">Select...</option>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
            <label>Supplier</label>
            <select value={form.supplier_id} onChange={(e) => setForm({ ...form, supplier_id: e.target.value })} required>
              <option value="">Select...</option>
              {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <label>Price</label>
            <input type="number" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} required />
            <p className="error-text">{error}</p>
            <button type="submit">Save</button>
          </form>
        </Modal>
      )}
    </section>
  );
}
