export default function Modal({ title, onClose, children }) {
  return (
    <div className="modal active" onClick={(e) => e.target.classList.contains("modal") && onClose()}>
      <div className="modal-box">
        <h2>{title}</h2>
        {children}
      </div>
    </div>
  );
}
