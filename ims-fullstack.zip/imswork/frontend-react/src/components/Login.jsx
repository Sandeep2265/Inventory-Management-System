import { useState } from "react";
import { api } from "../api.js";

const roles = [
  { key: "Admin", icon: "🛡️", text: "Full system administration" },
  { key: "Staff", icon: "👨‍💼", text: "Sales, purchases & operations" },
  { key: "Viewer", icon: "👁️", text: "Read-only access" },
  { key: "Auditor", icon: "📋", text: "Transactions & reports" },
];

export default function Login({ onLoggedIn, onCustomer }) {
  const [mode, setMode] = useState("landing");
  const [selectedRole, setSelectedRole] = useState("Admin");
  const [id, setId] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    try {
      const res = await api.login(id.trim(), password, selectedRole);
      onLoggedIn({ role: res.role, id: res.id, accountType: "employee" });
    } catch (err) { setError(err.message); }
  }

  if (mode === "landing") {
    return (
      <div className="auth-shell">
        <div className="auth-brand-panel">
          <div className="brand-mark">IMS</div>
          <p className="eyebrow">INVENTORY OPERATIONS</p>
          <h1>Inventory Management System</h1>
          <p className="brand-copy">A secure workspace for products, stock, suppliers, warehouses, sales and purchases.</p>
          <div className="brand-pills"><span>Real-time stock</span><span>Role-based access</span><span>SQL transactions</span></div>
        </div>
        <div className="auth-panel">
          <div className="auth-panel-inner">
            <p className="eyebrow">WELCOME</p>
            <h2>Choose how you want to continue</h2>
            <p className="muted">Select an internal role or enter through the customer portal.</p>
            <div className="portal-grid">
              <button className="portal-card employee" onClick={() => { setMode("employee"); setError(""); }}>
                <span className="portal-icon">🏢</span><span><strong>Employee Portal</strong><small>Admin, Staff, Viewer or Auditor</small></span><b>→</b>
              </button>
              <button className="portal-card" onClick={() => onCustomer("customer")}>
                <span className="portal-icon">🛍️</span><span><strong>Customer Login</strong><small>Access your customer account</small></span><b>→</b>
              </button>
            </div>
            <div className="signup-callout"><div><strong>New customer?</strong><span>Create an account in a few seconds.</span></div><button onClick={() => onCustomer("signup")}>Create account</button></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="auth-shell compact-auth">
      <div className="auth-panel auth-full">
        <div className="auth-form-wrap">
          <button className="back-button" onClick={() => { setMode("landing"); setError(""); }}>← Back</button>
          <div className="brand-mark small">IMS</div>
          <p className="eyebrow">EMPLOYEE PORTAL</p>
          <h2>Sign in to IMS</h2>
          <p className="muted">Your selected role is checked against the database account.</p>
          <div className="role-grid">
            {roles.map(r => <button key={r.key} className={`role-card ${selectedRole === r.key ? "selected" : ""}`} onClick={() => setSelectedRole(r.key)} type="button"><span>{r.icon}</span><strong>{r.key}</strong><small>{r.text}</small></button>)}
          </div>
          <form onSubmit={handleSubmit} className="modern-form">
            <label>Employee ID<input value={id} onChange={e => setId(e.target.value)} placeholder="e.g. 00" required /></label>
            <label>Password<input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter password" required /></label>
            {error && <div className="form-error">{error}</div>}
            <button className="primary-action" type="submit">Sign in as {selectedRole} <span>→</span></button>
          </form>
        </div>
      </div>
    </div>
  );
}
