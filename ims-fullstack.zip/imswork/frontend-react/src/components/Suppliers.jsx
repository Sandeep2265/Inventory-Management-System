import { useEffect, useState } from "react";
import { api } from "../api.js";
import Modal from "./Modal.jsx";

export default function Suppliers({ role }) {
  const [suppliers, setSuppliers] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", lat: 0, lng: 0 });
  const [error, setError] = useState("");
  const canEdit = role === "Admin";

  async function load() { setSuppliers(await api.getSuppliers()); }
  useEffect(() => { load(); }, []);

  async function handleAdd(e) {
    e.preventDefault();
    try {
      await api.addSupplier({ ...form, lat: +form.lat, lng: +form.lng });
      setShowForm(false); setForm({ name: "", phone: "", lat: 0, lng: 0 }); load();
    } catch (err) { setError(err.message); }
  }

  return (
    <section className="page active">
      <div className="page-header">
        <h1>Suppliers</h1>
        {canEdit && <button className="btn-primary" onClick={() => setShowForm(true)}>+ Add Supplier</button>}
      </div>
      <table>
        <thead><tr><th>ID</th><th>Name</th><th>Phone</th></tr></thead>
        <tbody>
          {suppliers.length === 0 && <tr><td colSpan="3">No suppliers yet</td></tr>}
          {suppliers.map((s) => <tr key={s.id}><td>#{s.id}</td><td>{s.name}</td><td>{s.phone ?? "-"}</td></tr>)}
        </tbody>
      </table>

      {showForm && (
        <Modal title="Add Supplier" onClose={() => setShowForm(false)}>
          <form onSubmit={handleAdd}>
            <label>Name</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
            <label>Phone</label>
            <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            <label>Latitude</label>
            <input type="number" step="0.0001" value={form.lat} onChange={(e) => setForm({ ...form, lat: e.target.value })} />
            <label>Longitude</label>
            <input type="number" step="0.0001" value={form.lng} onChange={(e) => setForm({ ...form, lng: e.target.value })} />
            <p className="error-text">{error}</p>
            <button type="submit">Save</button>
          </form>
        </Modal>
      )}
    </section>
  );
}
