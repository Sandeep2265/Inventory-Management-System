import { useEffect, useState } from "react";
import { api } from "../api.js";

export default function Reports() {
  const [items, setItems] = useState([]);

  useEffect(() => { api.getLowStock().then(setItems); }, []);

  return (
    <section className="page active">
      <h1>Low Stock Report</h1>
      <table>
        <thead><tr><th>Product</th><th>Stock</th><th>Threshold</th></tr></thead>
        <tbody>
          {items.length === 0 && <tr><td colSpan="3">Nothing is low on stock</td></tr>}
          {items.map((i) => <tr key={i.id}><td>{i.name}</td><td>{i.stock}</td><td>{i.threshold}</td></tr>)}
        </tbody>
      </table>
    </section>
  );
}
