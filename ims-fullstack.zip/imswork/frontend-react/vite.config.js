import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      // Any fetch("/api/...") from the app is forwarded to Flask.
      // This keeps the browser thinking everything is same-origin,
      // so session cookies from Flask's login work with no CORS setup.
      "/api": {
        target: "http://localhost:5000",
        changeOrigin: true,
      },
    },
  },
});
