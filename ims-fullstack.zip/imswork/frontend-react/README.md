# IMS — React Frontend

A React (Vite) rewrite of the plain-JS frontend. Same pages, same API,
same backend — this just swaps the View/Controller layer for React
components. `src/api.js` is the Model layer: every function is a real
fetch() call to your Flask API.

## Setup

1. Make sure the backend is running first (see the root `README.md`):
   ```bash
   cd ../backend
   python app.py
   ```
   This must stay running on `http://localhost:5000`.

2. In a separate terminal, install and run the React app:
   ```bash
   cd frontend-react
   npm install
   npm run dev
   ```

3. Open `http://localhost:5173`. Vite's dev server proxies every
   `/api/...` request to Flask (see `vite.config.js`), so there's no
   CORS setup needed and your login session cookie works normally.

## Structure

```
src/
  api.js              # Model — all fetch() calls to the Flask API
  App.jsx             # Controller — session state + page routing
  components/
    Login.jsx
    Sidebar.jsx
    Dashboard.jsx
    Products.jsx      # each page component is its own View,
    Categories.jsx     # fetching its own data and rendering it
    Suppliers.jsx
    Warehouses.jsx
    Sales.jsx          # goes through InsertSale stored procedure
    Purchases.jsx      # goes through InsertPurchase stored procedure
    Reports.jsx
    Modal.jsx
```

## Building for real deployment

```bash
npm run build
```
This outputs static files to `dist/`. Point Flask's `static_folder` in
`backend/app.py` at `frontend-react/dist` instead of `frontend/` to
serve the built React app from the same Flask server, if you want a
single deployable unit instead of two dev servers.
