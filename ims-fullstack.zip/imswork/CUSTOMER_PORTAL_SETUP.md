# IMS Frontend Redesign + Customer Portal

## 1. Build the redesigned React frontend

```bash
cd frontend-react
npm install
npm run build
```

The Flask backend serves `frontend-react/dist`, so rebuild after frontend changes.

## 2. Create the restricted customer MySQL account

From the project root:

```bash
sudo mysql < customer_setup.sql
```

The supplied password is `change_me_customer`. Change it in both MySQL and `backend/config.py` before real use.

## 3. Start Flask

```bash
cd backend
python3 app.py
```

Open:

```text
http://127.0.0.1:5000/
```

## 4. New authentication flow

- Employee Portal → Admin / Staff / Viewer / Auditor
- Customer Login → existing customer account
- Create Account → inserts a new customer into `Users`

The employee role selected on the UI is checked against the `Admins -> Roles` relationship by Flask.

Customer database access is restricted to `Users` plus read-only product/catalog views.
