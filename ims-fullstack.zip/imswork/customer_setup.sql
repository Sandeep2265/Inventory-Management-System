-- Run once on the existing IMS database.
-- Change this password before real deployment.
CREATE USER IF NOT EXISTS 'ims_customer'@'localhost' IDENTIFIED BY 'change_me_customer';
GRANT SELECT, INSERT ON IMS.Users TO 'ims_customer'@'localhost';
GRANT SELECT ON IMS.Products TO 'ims_customer'@'localhost';
GRANT SELECT ON IMS.ProductStockSummary TO 'ims_customer'@'localhost';
GRANT SELECT ON IMS.Categories TO 'ims_customer'@'localhost';
FLUSH PRIVILEGES;
