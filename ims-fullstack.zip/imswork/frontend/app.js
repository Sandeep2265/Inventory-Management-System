const API = "/api";

// ===================== MODEL =====================
// Every method here talks to the real MySQL database through the Flask API.
class Model {
  async request(path, options = {}) {
    const res = await fetch(API + path, {
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      ...options,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.message || `Request failed (${res.status})`);
    return data;
  }

  login(id, password) {
    return this.request("/login", { method: "POST", body: JSON.stringify({ id, password }) });
  }
  logout() {
    return this.request("/logout", { method: "POST" });
  }
  me() {
    return this.request("/me");
  }

  getProducts() { return this.request("/products"); }
  addProduct(p) { return this.request("/products", { method: "POST", body: JSON.stringify(p) }); }
  updateProduct(id, p) { return this.request(`/products/${id}`, { method: "PUT", body: JSON.stringify(p) }); }
  deleteProduct(id) { return this.request(`/products/${id}`, { method: "DELETE" }); }

  getCategories() { return this.request("/categories"); }
  addCategory(c) { return this.request("/categories", { method: "POST", body: JSON.stringify(c) }); }

  getSuppliers() { return this.request("/suppliers"); }
  addSupplier(s) { return this.request("/suppliers", { method: "POST", body: JSON.stringify(s) }); }

  getWarehouses() { return this.request("/warehouses"); }
  addWarehouse(w) { return this.request("/warehouses", { method: "POST", body: JSON.stringify(w) }); }

  getSales() { return this.request("/sales"); }
  addSale(s) { return this.request("/sales", { method: "POST", body: JSON.stringify(s) }); }

  getPurchases() { return this.request("/purchases"); }
  addPurchase(p) { return this.request("/purchases", { method: "POST", body: JSON.stringify(p) }); }

  getLowStock() { return this.request("/reports/low-stock"); }
}

// ===================== VIEW =====================
class View {
  showApp(role) {
    document.getElementById("login-screen").classList.add("hidden");
    document.getElementById("app").classList.remove("hidden");
    document.getElementById("session-label").textContent = `Logged in as ${role}`;
    this.applyRoleVisibility(role);
  }

  showLogin(message = "") {
    document.getElementById("app").classList.add("hidden");
    document.getElementById("login-screen").classList.remove("hidden");
    document.getElementById("login-error").textContent = message;
  }

  applyRoleVisibility(role) {
    const isAdmin = role === "Admin";
    const isAdminStaff = role === "Admin" || role === "Staff";
    document.querySelectorAll(".role-admin").forEach(el => el.classList.toggle("hidden", !isAdmin));
    document.querySelectorAll(".role-admin-staff").forEach(el => el.classList.toggle("hidden", !isAdminStaff));
  }

  showPage(name) {
    document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
    document.getElementById(`${name}-page`).classList.add("active");
    document.querySelectorAll(".nav-link").forEach(l => l.classList.remove("active"));
    document.querySelector(`[data-page="${name}"]`).classList.add("active");
  }

  renderDashboard({ products, suppliers, lowStock }) {
    document.getElementById("stat-products").textContent = products.length;
    document.getElementById("stat-value").textContent =
      "₹" + products.reduce((sum, p) => sum + p.stock * p.price, 0).toLocaleString();
    document.getElementById("stat-lowstock").textContent = lowStock.length;
    document.getElementById("stat-suppliers").textContent = suppliers.length;
  }

  renderProducts(products, categories, suppliers) {
    const body = document.getElementById("products-body");
    body.innerHTML = products.map(p => {
      const cat = categories.find(c => c.id === p.category_id);
      const sup = suppliers.find(s => s.id === p.supplier_id);
      const low = p.stock <= p.threshold;
      return `<tr>
        <td>#${p.id}</td><td>${p.name}</td><td>${cat ? cat.name : "-"}</td><td>${sup ? sup.name : "-"}</td>
        <td>${p.stock}</td><td>₹${Number(p.price).toLocaleString()}</td>
        <td class="${low ? "status-low" : "status-ok"}">${low ? "Low" : "OK"}</td>
        <td class="role-admin-staff">
          <button onclick="controller.deleteProduct(${p.id})">Delete</button>
        </td>
      </tr>`;
    }).join("") || `<tr><td colspan="8">No products yet</td></tr>`;
  }

  renderCategories(categories) {
    document.getElementById("categories-body").innerHTML = categories.map(c =>
      `<div class="category-card"><h4>${c.name}</h4></div>`
    ).join("") || "<p>No categories yet</p>";
  }

  renderSuppliers(suppliers) {
    document.getElementById("suppliers-body").innerHTML = suppliers.map(s =>
      `<tr><td>#${s.id}</td><td>${s.name}</td><td>${s.phone ?? "-"}</td></tr>`
    ).join("") || `<tr><td colspan="3">No suppliers yet</td></tr>`;
  }

  renderWarehouses(warehouses) {
    document.getElementById("warehouses-body").innerHTML = warehouses.map(w =>
      `<tr><td>#${w.id}</td><td>${w.name}</td></tr>`
    ).join("") || `<tr><td colspan="2">No warehouses yet</td></tr>`;
  }

  renderSales(sales) {
    document.getElementById("sales-body").innerHTML = sales.map(s =>
      `<tr><td>#${s.id}</td><td>${s.user_id}</td><td>${s.product_name}</td><td>${s.quantity}</td><td>₹${s.price}</td></tr>`
    ).join("") || `<tr><td colspan="5">No sales yet</td></tr>`;
  }

  renderPurchases(purchases) {
    document.getElementById("purchases-body").innerHTML = purchases.map(p =>
      `<tr><td>#${p.id}</td><td>${p.supplier_id}</td><td>${p.product_name}</td><td>${p.quantity}</td><td>₹${p.price}</td></tr>`
    ).join("") || `<tr><td colspan="5">No purchases yet</td></tr>`;
  }

  renderLowStock(items) {
    document.getElementById("lowstock-body").innerHTML = items.map(i =>
      `<tr><td>${i.name}</td><td>${i.stock}</td><td>${i.threshold}</td></tr>`
    ).join("") || `<tr><td colspan="3">Nothing is low on stock</td></tr>`;
  }

  openModal(title, fieldsHtml, onSubmit) {
    document.getElementById("modal-title").textContent = title;
    const form = document.getElementById("modal-form");
    form.innerHTML = fieldsHtml + `<button type="submit">Save</button>`;
    document.getElementById("modal").classList.add("active");
    form.onsubmit = (e) => { e.preventDefault(); onSubmit(new FormData(form)); };
  }

  closeModal() {
    document.getElementById("modal").classList.remove("active");
  }

  alert(message) {
    window.alert(message);
  }
}

// ===================== CONTROLLER =====================
class Controller {
  constructor(model, view) {
    this.model = model;
    this.view = view;
    this.state = { products: [], categories: [], suppliers: [], warehouses: [] };
    this.bindNav();
    document.getElementById("login-form").addEventListener("submit", (e) => this.handleLogin(e));
    document.getElementById("logout-btn").addEventListener("click", () => this.handleLogout());
  }

  bindNav() {
    document.querySelectorAll(".nav-link").forEach(link => {
      link.addEventListener("click", (e) => {
        e.preventDefault();
        const page = e.currentTarget.dataset.page;
        this.view.showPage(page);
        this.loadPage(page);
      });
    });
  }

  async init() {
    try {
      const me = await this.model.me();
      if (me.logged_in) {
        this.view.showApp(me.role);
        await this.loadPage("dashboard");
      } else {
        this.view.showLogin();
      }
    } catch {
      this.view.showLogin();
    }
  }

  async handleLogin(e) {
    e.preventDefault();
    const id = document.getElementById("login-id").value;
    const password = document.getElementById("login-password").value;
    try {
      const res = await this.model.login(id, password);
      this.view.showApp(res.role);
      await this.loadPage("dashboard");
    } catch (err) {
      this.view.showLogin(err.message);
    }
  }

  async handleLogout() {
    await this.model.logout();
    this.view.showLogin();
  }

  async loadPage(page) {
    try {
      if (page === "dashboard") {
        const [products, suppliers, lowStock] = await Promise.all([
          this.model.getProducts(), this.model.getSuppliers(), this.model.getLowStock(),
        ]);
        this.view.renderDashboard({ products, suppliers, lowStock });
      } else if (page === "products") {
        const [products, categories, suppliers] = await Promise.all([
          this.model.getProducts(), this.model.getCategories(), this.model.getSuppliers(),
        ]);
        Object.assign(this.state, { products, categories, suppliers });
        this.view.renderProducts(products, categories, suppliers);
      } else if (page === "categories") {
        this.state.categories = await this.model.getCategories();
        this.view.renderCategories(this.state.categories);
      } else if (page === "suppliers") {
        this.state.suppliers = await this.model.getSuppliers();
        this.view.renderSuppliers(this.state.suppliers);
      } else if (page === "warehouses") {
        this.state.warehouses = await this.model.getWarehouses();
        this.view.renderWarehouses(this.state.warehouses);
      } else if (page === "sales") {
        this.view.renderSales(await this.model.getSales());
      } else if (page === "purchases") {
        this.view.renderPurchases(await this.model.getPurchases());
      } else if (page === "reports") {
        this.view.renderLowStock(await this.model.getLowStock());
      }
    } catch (err) {
      this.view.alert(err.message);
    }
  }

  // ---- forms ----
  async openProductForm() {
    const [categories, suppliers] = await Promise.all([this.model.getCategories(), this.model.getSuppliers()]);
    const catOptions = categories.map(c => `<option value="${c.id}">${c.name}</option>`).join("");
    const supOptions = suppliers.map(s => `<option value="${s.id}">${s.name}</option>`).join("");
    this.view.openModal("Add Product", `
      <label>Name</label><input name="name" required>
      <label>Category</label><select name="category_id">${catOptions}</select>
      <label>Supplier</label><select name="supplier_id">${supOptions}</select>
      <label>Price</label><input name="price" type="number" step="0.01" required>
    `, async (form) => {
      await this.model.addProduct({
        name: form.get("name"), category_id: +form.get("category_id"),
        supplier_id: +form.get("supplier_id"), price: +form.get("price"),
      });
      this.view.closeModal();
      this.loadPage("products");
    });
  }

  async deleteProduct(id) {
    if (!confirm("Delete this product?")) return;
    try {
      await this.model.deleteProduct(id);
      this.loadPage("products");
    } catch (err) { this.view.alert(err.message); }
  }

  openCategoryForm() {
    this.view.openModal("Add Category", `<label>Name</label><input name="name" required>`, async (form) => {
      await this.model.addCategory({ name: form.get("name") });
      this.view.closeModal();
      this.loadPage("categories");
    });
  }

  openSupplierForm() {
    this.view.openModal("Add Supplier", `
      <label>Name</label><input name="name" required>
      <label>Phone</label><input name="phone">
      <label>Latitude</label><input name="lat" type="number" step="0.0001" value="0">
      <label>Longitude</label><input name="lng" type="number" step="0.0001" value="0">
    `, async (form) => {
      await this.model.addSupplier({
        name: form.get("name"), phone: form.get("phone"),
        lat: +form.get("lat"), lng: +form.get("lng"),
      });
      this.view.closeModal();
      this.loadPage("suppliers");
    });
  }

  openWarehouseForm() {
    this.view.openModal("Add Warehouse", `
      <label>Name</label><input name="name" required>
      <label>Latitude</label><input name="lat" type="number" step="0.0001" value="0">
      <label>Longitude</label><input name="lng" type="number" step="0.0001" value="0">
    `, async (form) => {
      await this.model.addWarehouse({ name: form.get("name"), lat: +form.get("lat"), lng: +form.get("lng") });
      this.view.closeModal();
      this.loadPage("warehouses");
    });
  }

  async openSaleForm() {
    const [products, warehouses] = await Promise.all([this.model.getProducts(), this.model.getWarehouses()]);
    const prodOptions = products.map(p => `<option value="${p.id}">${p.name}</option>`).join("");
    const whOptions = warehouses.map(w => `<option value="${w.id}">${w.name}</option>`).join("");
    this.view.openModal("Record Sale", `
      <label>User ID</label><input name="user_id" required>
      <label>Product</label><select name="product_id">${prodOptions}</select>
      <label>Warehouse</label><select name="warehouse_id">${whOptions}</select>
      <label>Quantity</label><input name="quantity" type="number" min="1" required>
    `, async (form) => {
      try {
        await this.model.addSale({
          user_id: form.get("user_id"), product_id: +form.get("product_id"),
          warehouse_id: +form.get("warehouse_id"), quantity: +form.get("quantity"),
        });
        this.view.closeModal();
        this.loadPage("sales");
      } catch (err) { this.view.alert(err.message); }
    });
  }

  async openPurchaseForm() {
    const [products, suppliers] = await Promise.all([this.model.getProducts(), this.model.getSuppliers()]);
    const prodOptions = products.map(p => `<option value="${p.id}">${p.name}</option>`).join("");
    const supOptions = suppliers.map(s => `<option value="${s.id}">${s.name}</option>`).join("");
    this.view.openModal("Record Purchase", `
      <label>Supplier</label><select name="supplier_id">${supOptions}</select>
      <label>Product</label><select name="product_id">${prodOptions}</select>
      <label>Quantity</label><input name="quantity" type="number" min="1" required>
    `, async (form) => {
      try {
        await this.model.addPurchase({
          supplier_id: +form.get("supplier_id"), product_id: +form.get("product_id"),
          quantity: +form.get("quantity"),
        });
        this.view.closeModal();
        this.loadPage("purchases");
      } catch (err) { this.view.alert(err.message); }
    });
  }
}

const model = new Model();
const view = new View();
const controller = new Controller(model, view);
controller.init();

// close modal on backdrop click
document.getElementById("modal").addEventListener("click", (e) => {
  if (e.target.id === "modal") view.closeModal();
});
